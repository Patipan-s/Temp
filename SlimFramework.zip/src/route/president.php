<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app = new \Slim\App;

//get all president 
$app->get('/product',function(Request $request, Response $response){
    $sql = "SELECT * FROM productlists";
    try{
        $db = new db();
        $db = $db->connect();
        $stmt = $db->query($sql);
        $president = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db = null;
        // header('Content-type:application/json;charset=utf-8');
        echo json_encode($president,JSON_PRETTY_PRINT);
        // return $response->withJson($product, 200, JSON_NUMERIC_CHECK);
        // JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE
    }catch(PDOException $e){
        echo $e->getMessage();
    }
});
// slimpresident/public/main

//GET Single Product
$app->get('/product/{productID}',function(Request $request, Response $response){
    $id = $request ->getAttribute('productID');
    $sql = "SELECT * FROM productlists WHERE pd_id = $id";
    
    try {
        $db = new db();
        $db = $db->connect();

         $stmt =$db->query($sql);

        $product = $stmt->fetchAll(PDO::FETCH_OBJ);
        $db = null;
        echo json_encode($product);
    }catch(PDOException $e){
        echo'{"error":{"text":}'.$e->getMessage().'}';
    }
});

//Add Products
$app->post('/product/add',function(Request $request, Response $response) {

    $type = $request->getParam('type') ;
    $name = $request->getParam('name') ;
    $cost = $request->getParam('cost') ;

    $sql ="INSERT INTO productlists (type,name,cost) VALUES (:type,:name,:cost)" ;

    try {
        //get DB object
        $db = new db();
        //connect
        $db = $db->connect();
        $stmt = $db->prepare($sql);

        $stmt->bindParam(':type',       $type);
        $stmt->bindParam(':name',       $name);
        $stmt->bindParam(':cost',       $cost);

        $stmt->execute() ;

        echo '{"notice: {"text": "Product Add"}' ;
    } catch(PDOExcaption $e) {
            echo '{"error":{"text": '.$e->getMessage().'}' ;
    }
});
//http://slimpresident/public/product/add?type=3&name=water&cost=79

//Update Products
$app->put('/product/update/{id}',function(Request $request, Response $response) {

    $id = $request->getAttribute('id');
    $type = $request->getParam('type');
    $name = $request->getParam('name');
    $cost = $request->getParam('cost');

    
    $sql = "UPDATE productlists SET
            type = :type,
            name = :name,
            cost = :cost
            WHERE pd_id = $id" ;
    try{
        //Get DB Object
        $db = new db() ;
        // Connect
        $db = $db->connect() ;
        $stmt = $db->prepare($sql) ;
        $stmt->bindParam(':type',     $type) ;
        $stmt->bindParam(':name',    $name) ;
        $stmt->bindParam(':cost',    $cost) ;

        $stmt->execute() ;
        echo '{"notice": {"text": "Product Update"}' ;
    } catch(PODExution $e) {
        echo '{"error": {"text": '.$e->getMessage().'}' ;
    }
});
//http://slimpresident/public/product/update/15?type=3&name=water&cost=15  15 กำหนดเอง ที่เหลือเป็น params

//Delete Product
$app->delete('/product/delete/{id}', function(Request $request, Response $response){
    $id = $request->getAttribute('id');
    $sql = "DELETE FROM productlists WHERE pd_id = $id";
    try{
        //Get DB Object
        $db = new db();
        //connect
        $db = $db->connect();
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $db = null;
        echo '{"notice": {"text": "Product Deleted"}';
    }  catch(PDOException $e){
        echo '{"error": {"text": '.$e->getMessage().'}';
    }
});
//http://slimpresident/public/product/delete/18